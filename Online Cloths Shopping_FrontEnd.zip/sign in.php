<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $mail = $_POST['email'];
	$pass = $_POST['password'];
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "clothes shopping";

$conn = mysqli_connect($servername, $username, $password, $database);


if (!$conn){
	die("sorry we failed to connect: ". mysqli_connect_error());
}
echo "connection was succesful";


$sql = "INSERT INTO `login info` (`id`, `mail`, `password`) VALUES (NULL, '$mail', '$pass')";

$result = mysqli_query($conn, $sql);





?>