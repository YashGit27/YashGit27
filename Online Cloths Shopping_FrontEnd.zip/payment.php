<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $name = $_POST['name'];
	$lastname = $_POST['lastname'];
    $address = $_POST['adress'];
    $username = $_POST['username'];
    $country = $_POST['country'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];
    $namecard = $_POST['namecard'];
    $cardno = $_POST['cardno'];
    $exp = $_POST['exp'];
    $cvv = $_POST['cvv'];

}

$servername = "localhost";
$username = "root";
$password = "";
$database = "clothes shopping";

$conn = mysqli_connect($servername, $username, $password, $database);


if (!$conn){
	die("sorry we failed to connect: ". mysqli_connect_error());
}
echo "connection was succesful";


$sql = "INSERT INTO `login info` (`id`, `mail`, `password`) VALUES (NULL, '$mail', '$pass')";

$result = mysqli_query($conn, $sql);










?>